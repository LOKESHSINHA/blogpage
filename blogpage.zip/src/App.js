import React from 'react';
import './App.css';
import Navbar from './componant/Navbar';
import TechnologyNews from './componant/TechnologyNews';
import 'bootstrap/dist/css/bootstrap.css';
import SportsNews from './componant/SportsNews';
import EntertainmentNews from './componant/EntertainmentNews';
import HealthWellnessNews from './componant/HealthWellnessNews';
import GeneralNews from './componant/GeneralNews';
function App() {

  return (
    <>
    
     <Navbar/>
  
          </>
  );
}

export default App;

