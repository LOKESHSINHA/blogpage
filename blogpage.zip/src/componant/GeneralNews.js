import React from 'react';

const GeneralNews = () => {
  return (
    <div className="container">
      <h2 className="mt-4 mb-3">General News</h2>
      {/* Add your content for the General News page */}
      <div className="card">
        <div className="card-body">
          <h5 className="card-title">Breaking News</h5>
          <p className="card-text">Stay informed with the latest breaking news from around the world.</p>
          <a href="#" className="btn btn-primary">Read More</a>
        </div>
      </div>
      <div className="card mt-3">
        <div className="card-body">
          <h5 className="card-title">Feature Stories</h5>
          <p className="card-text">Explore in-depth feature stories covering a wide range of topics.</p>
          <a href="#" className="btn btn-primary">Read More</a>
        </div>
      </div>
      <div className="card mt-3">
        <div className="card-body">
          <h5 className="card-title">Opinion Pieces</h5>
          <p className="card-text">Read thought-provoking opinion pieces and editorials on current issues.</p>
          <a href="#" className="btn btn-primary">Read More</a>
        </div>
      </div>
    </div>
  );
};

export default GeneralNews;
