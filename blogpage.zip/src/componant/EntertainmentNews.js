import React from 'react';

const EntertainmentNews = () => {
  return (
    <div className="container">
      <h2 className="mt-4 mb-3">Entertainment News</h2>
      {/* Add your content for the Entertainment News page */}
      <div className="card">
        <div className="card-body">
          <h5 className="card-title">Movie Reviews</h5>
          <p className="card-text">Read reviews of the latest movies and discover new releases.</p>
          <a href="#" className="btn btn-primary">Read More</a>
        </div>
      </div>
      <div className="card mt-3">
        <div className="card-body">
          <h5 className="card-title">Celebrity Gossip</h5>
          <p className="card-text">Stay updated on the latest celebrity news and gossip from the entertainment industry.</p>
          <a href="#" className="btn btn-primary">Read More</a>
        </div>
      </div>
      <div className="card mt-3">
        <div className="card-body">
          <h5 className="card-title">Music Releases</h5>
          <p className="card-text">Explore new music releases, album reviews, and artist interviews.</p>
          <a href="#" className="btn btn-primary">Read More</a>
        </div>
      </div>
    </div>
  );
};

export default EntertainmentNews;
