import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

function DigitalMarketing() {
  return (
    <div className="digital-marketing" style={{ margin: '20px' }}>
      <div className="content">
        <h1>Digital Marketing</h1>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec est consectetur, iaculis massa ut, convallis mauris. Vivamus fringilla, felis non aliquet tincidunt, elit orci congue velit, vel eleifend purus urna in nibh.</p>
        <button className="btn btn-primary">Click Me</button>
      </div>
    </div>
  );
}

export default DigitalMarketing;
