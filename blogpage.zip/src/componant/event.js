import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';

const EventPage = () => {
  const eventTitleStyle = {
    fontSize: '24px',
    fontWeight: 'bold',
    marginBottom: '10px',
  };

  const eventDetailsStyle = {
    marginBottom: '20px',
  };

  return (
    <Container>
      <h1 style={eventTitleStyle}>Event Name</h1>
      <div style={eventDetailsStyle}>
        <p>Date: June 30, 2023</p>
        <p>Location: City, Country</p>
        <p>Time: 7:00 PM</p>
      </div>
      <Row>
        <Col md={6}>
          <img src="event-image.jpg" alt="Event Image" className="img-fluid" />
        </Col>
        <Col md={6}>
          <h3>About the Event</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla luctus aliquam dolor, non aliquam erat facilisis ut. Nulla facilisi. Fusce non laoreet urna. Nullam ac nisi nec purus sodales gravida. Suspendisse potenti.</p>
          <p>Morbi sed massa ac nibh eleifend bibendum. Mauris luctus felis ac interdum pharetra. In sed vestibulum neque, vitae vestibulum eros.</p>
        </Col>
      </Row>
    </Container>
  );
};

export default EventPage;
