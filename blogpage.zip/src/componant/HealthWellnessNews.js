import React from 'react';

const HealthWellnessNews = () => {
  return (
    <div className="container">
      <h2 className="mt-4 mb-3">Health & Wellness News</h2>
      {/* Add your content for the Health & Wellness News page */}
      <div className="card">
        <div className="card-body">
          <h5 className="card-title">Healthy Eating Habits</h5>
          <p className="card-text">Learn about the importance of maintaining a balanced diet and healthy eating habits.</p>
          <a href="#" className="btn btn-primary">Read More</a>
        </div>
      </div>
      <div className="card mt-3">
        <div className="card-body">
          <h5 className="card-title">Fitness Tips</h5>
          <p className="card-text">Discover effective fitness tips and exercises to stay active and maintain a healthy lifestyle.</p>
          <a href="#" className="btn btn-primary">Read More</a>
        </div>
      </div>
      <div className="card mt-3">
        <div className="card-body">
          <h5 className="card-title">Mental Health Awareness</h5>
          <p className="card-text">Explore strategies for promoting mental well-being and managing stress.</p>
          <a href="#" className="btn btn-primary">Read More</a>
        </div>
      </div>
    </div>
  );
};

export default HealthWellnessNews;
