import React from 'react';
import { Button, Form } from 'react-bootstrap';

const Home = () => {
  const blogPosts = [
    {
      title: 'Blog Post 1',
      author: 'John Doe',
      content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
    },
    {
      title: 'Blog Post 2',
      author: 'Jane Smith',
      content: 'Pellentesque ac ligula in tellus feugiat maximus.',
    },
    {
      title: 'Blog Post 3',
      author: 'Bob Johnson',
      content: 'Sed varius arcu non justo commodo, ut convallis metus rutrum.',
    },
  ];

  return (
    <div>
      <h1 className="text-center mb-4">Welcome to the Blog!</h1>

      {blogPosts.map((post, index) => (
        <div key={index} className="card mb-4">
          <div className="card-body">
            <h2 className="card-title">{post.title}</h2>
            <h4 className="card-subtitle mb-2 text-muted">By {post.author}</h4>
            <p className="card-text">{post.content}</p>
          </div>
        </div>
      ))}

      <div className="mt-5">
        <h3 className="mb-3">Create a New Blog Post</h3>
        <Form>
          <Form.Group controlId="formTitle">
            <Form.Label>Title</Form.Label>
            <Form.Control type="text" placeholder="Enter title" />
          </Form.Group>

          <Form.Group controlId="formAuthor">
            <Form.Label>Author</Form.Label>
            <Form.Control type="text" placeholder="Enter author" />
          </Form.Group>

          <Form.Group controlId="formContent">
            <Form.Label>Content</Form.Label>
            <Form.Control as="textarea" rows={4} placeholder="Enter content" />
          </Form.Group>

          <Button variant="primary" type="submit">
            Upload
          </Button>
        </Form>
      </div>
    </div>
  );
};

export default Home;
