import React from 'react';
import 'bootstrap/dist/css/bootstrap.css';

const Job = ({ jobData = {}, header = "" }) => {
  return (
    <div className="container">
      <h1 className="my-4">{header}</h1>
      <h2 className="my-2">{jobData.company}</h2>
      <h3 className="my-2">{jobData.location}</h3>
      <div className="card my-4">
        <div className="card-body">
          <h4 className="card-title">Description:</h4>
          <p className="card-text">{jobData.description}</p>
        </div>
      </div>
      <div className="card my-4">
        <div className="card-body">
          <h4 className="card-title">Requirements:</h4>
          <ul className="list-group">
            {jobData.requirements && jobData.requirements.map((requirement, index) => (
              <li key={index} className="list-group-item">{requirement}</li>
            ))}
          </ul>
        </div>
      </div>
      <div className="card my-4">
        <div className="card-body">
          <h4 className="card-title">Responsibilities:</h4>
          <ul className="list-group">
            {jobData.responsibilities && jobData.responsibilities.map((responsibility, index) => (
              <li key={index} className="list-group-item">{responsibility}</li>
            ))}
          </ul>
        </div>
      </div>
      <a href="#" className="btn btn-primary" target="_blank" rel="noopener noreferrer">
        Apply Now
      </a>
    </div>
  );
};

export default Job;
