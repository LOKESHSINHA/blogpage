---
title: Basic (Data Router)
toc: false
order: 1
---

# Data Routers

This example demonstrates a simple usage of a Data Router, using `createBrowserRouter` and `<RouterProvider>`.

## Preview

Open this example on [StackBlitz](https://stackblitz.com):

[![Open in StackBlitz](https://developer.stackblitz.com/img/open_in_stackblitz.svg)](https://stackblitz.com/github/remix-run/react-router/tree/main/examples/basic-data-router?file=src/App.tsx)
