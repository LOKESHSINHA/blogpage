# Title

Date: YYYY-MM-DD

Status: proposed | rejected | accepted | deprecated | … | superseded by [0005](0005-example.md)

## Context

## Decision

## Consequences
