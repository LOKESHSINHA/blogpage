import * as React from "react";

export default function LazyComponent() {
  return <h1>Lazy</h1>;
}
