---
title: createRoutesFromChildren
---

# `createRoutesFromChildren`

Alias for [`createRoutesFromElements`][createroutesfromelements]

[createroutesfromelements]: ./create-routes-from-elements
