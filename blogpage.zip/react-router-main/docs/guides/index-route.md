---
title: Index Route
new: true
hidden: true
---

# Index Route

<docs-info>TODO</docs-info>
