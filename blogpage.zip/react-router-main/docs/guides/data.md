---
title: Data Synchronization
hidden: true
---

# Data Synchronization

React Router not only keeps your UI in sync with the URL, but also your data. It does this with several APIs

- [loader][loader]
- [action][action]
- [Form][form]
- [useFetcher][use-fetcher]
