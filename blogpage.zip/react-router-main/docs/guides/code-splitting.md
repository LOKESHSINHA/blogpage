---
title: Code Splitting
new: true
hidden: true
---

# Code Splitting

<docs-info>TODO: This doc is a stub</docs-info>
