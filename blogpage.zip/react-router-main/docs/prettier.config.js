/**
 * @type {import('prettier').Options}
 */
module.exports = {
  ...require("../prettier.config"),
  printWidth: 60,
};
