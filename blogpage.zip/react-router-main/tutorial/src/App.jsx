import * as React from "react";

export default function App() {
  return (
    <div>
      <h1>Bookkeeper</h1>
    </div>
  );
}
